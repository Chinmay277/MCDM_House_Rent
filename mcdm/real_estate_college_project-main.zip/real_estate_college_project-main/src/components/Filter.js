import React, { Component } from "react";
var CityJson = require("../CityName/cities.json");
var StateJson = require("../CityName/state.json");
export default class Properties extends Component {
  constructor(props) {
    super(props);
    this.state = {
      City: "",
      State: "",
      ResultData: [],

    };
  }

  componentDidMount() {
    debugger;

  }
  componentDidUpdate() {
    debugger;
    let a = document.getElementById("tooltip-inner")
  }
  cityandstate = (e) => {
    debugger

    let cityState = e.target.value.split(",");
    this.setState({ City: cityState[1], State: cityState[0] })
  }
  SetStateName = (e) => {
    debugger

    let a = e.target.value;
    this.setState({ State: e.target.value })
  }
  returnDatausingID = (e) => {
    return e.textContent;
  }
  returnDataofcheckbox = (e) => {
    return e.checked;
  }
  AllFilaterData = () => {
    debugger
    let priceRange = this.returnDatausingID(document.getElementById("tooltip-inner1"));
    let propertyRange = this.returnDatausingID(document.getElementById("tooltip-inner2"));
    let Deposite = this.returnDatausingID(document.getElementById("tooltip-inner3"));
    let bedRange = this.returnDatausingID(document.getElementById("tooltip-inner4"));
    let Filterfullfurniture = this.returnDataofcheckbox(document.getElementById("Filterfullfurniture"));
    let Filtersemifurniture = this.returnDataofcheckbox(document.getElementById("Filtersemifurniture"));
    let FilterNonefurniture = this.returnDataofcheckbox(document.getElementById("FilterNonefurniture"));
    let FilterSwimmingPool = this.returnDataofcheckbox(document.getElementById("FilterSwimmingPool"));
    let FilterGym = this.returnDataofcheckbox(document.getElementById("FilterGym"));
    let FilterGarden = this.returnDataofcheckbox(document.getElementById("FilterGarden"));
    let Filterswim = this.returnDataofcheckbox(document.getElementById("Filterswim"));

    let cityName = this.state.City, stateName = this.state.State;
  }

  render() {
    debugger;
    let a = this.state.State
    return (
      <>
        <div
          className="home-lager-shearch"
          style={{
            backgroundColor: "rgb(252, 252, 252)",
            paddingTop: 25,
            marginTop: "-125px",
          }}
        >
          <div className="container">
            <div
              className="col-md-12 large-search"
              style={{ margin: "8rem 0px 0px -21px" }}
            >
              <div className="search-form wow pulse animated">
                <form action className=" form-inline">
                  <div className="col-md-12">
                    <div className="col-md-4">
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Key word"
                      />
                    </div>
                    <div className="col-md-4">
                      <div className="btn-group bootstrap-select">
                        <div
                          className="dropdown-menu open"
                          style={{
                            maxHeight: 335,
                            overflow: "hidden",
                            minHeight: 161,
                          }}
                        >
                          <div className="bs-searchbox">
                            <input
                              type="text"
                              className="form-control"
                              autoComplete="off"
                            />
                          </div>
                        </div>
                        <select
                          id="lunchBegins"
                          className="selectpicker"
                          data-live-search="true"
                          data-live-search-style="begins"
                          title="Select your city"
                          tabIndex={-98}
                          onChange={this.cityandstate}
                        >
                          <option className="bs-title-option" value={this.state.City}>
                            Select your city
                          </option>
                          {(CityJson || []).map((user, index) => (

                            (this.state.State === "" || this.state.State === user.state) ?
                              <option value={[user.state, user.name]} id={user.name}>
                                {() => { debugger }}
                                {user.name}
                              </option>
                              : null
                          ))}
                        </select>
                      </div>
                    </div>

                    {/* <div className="col-md-4">                                   
              <select id="lunchBegins" className="selectpicker show-tick form-control" data-live-search="true" data-live-search-style="begins" title="Select your city">
                <option>New york, CA</option>
                <option>Paris</option>
                <option>Casablanca</option>
                <option>Tokyo</option>
                <option>Marraekch</option>
                <option>kyoto , shibua</option>
              </select>
            </div> */}
                    <div className="col-md-4">
                      <select
                        id="basic"
                        className="selectpicker show-tick form-control"
                        value={this.state.State}
                        onChange={this.SetStateName}
                      >
                        {(StateJson || []).map((user, index) => (

                          <option value={user.name} id={user.name}>
                            {user.name}
                          </option>

                        )
                        )
                        }

                      </select>
                    </div>
                  </div>
                  <div className="col-md-12 ">
                    {/* <div className="search-row">   
              <div className="col-sm-3">
                <label htmlFor="price-range">Price range ($):</label>
                <input type="text" className="span2" defaultValue data-slider-min={0} data-slider-max={600} data-slider-step={5} data-slider-value="[0,450]" id="price-range" /><br />
                <b className="pull-left color">2000$</b> 
                <b className="pull-right color">100000$</b>
              </div>
        
              <div className="col-sm-3">
                <label htmlFor="property-geo">Property geo (m2) :</label>
                <input type="text" className="span2" defaultValue data-slider-min={0} data-slider-max={600} data-slider-step={5} data-slider-value="[50,450]" id="property-geo" /><br />
                <b className="pull-left color">40m</b> 
                <b className="pull-right color">12000m</b>
              </div>
              <div className="col-sm-3">
                <label htmlFor="price-range">Min baths :</label>
                <input type="text" className="span2" defaultValue data-slider-min={0} data-slider-max={600} data-slider-step={5} data-slider-value="[250,450]" id="min-baths" /><br />
                <b className="pull-left color">1</b> 
                <b className="pull-right color">120</b>
              </div>
              <div className="col-sm-3">
                <label htmlFor="property-geo">Min bed :</label>
                <input type="text" className="span2" defaultValue data-slider-min={0} data-slider-max={600} data-slider-step={5} data-slider-value="[250,450]" id="min-bed" /><br />
                <b className="pull-left color">1</b> 
                <b className="pull-right color">120</b>
              </div>
            </div>
           
            */}
                    <div className="search-row">
                      <div className="col-sm-3">
                        <label htmlFor="price-range">Price range ($):</label>
                        <div
                          className="sliderrange slider slider-horizontal"
                          style={{ width: 235 }}
                        >
                          <div
                            className="tooltip top"
                            style={{ top: "-26px", left: "106.5px" }}
                          >
                            <div className="tooltip-arrow" />
                            <div className="tooltip-inner" id="tooltip-inner1">150 : 450</div>
                          </div>
                          <input
                            type="text"
                            className="span2"
                            defaultValue
                            data-slider-min={0}
                            data-slider-max={600}
                            data-slider-step={5}
                            data-slider-value="[0,450]"
                            id="price-range"
                            onChange={(e) => {
                              console.log(e.target);
                            }}
                          />
                        </div>
                        <br />
                        <b className="pull-left color">2000$</b>
                        <b className="pull-right color">100000$</b>
                      </div>
                      {/* End of  */}
                      <div className="col-sm-3">
                        <label htmlFor="property-geo">
                          Property geo (m2) :
                        </label>
                        <div
                          className="sliderrange slider slider-horizontal"
                          style={{ width: 235 }}
                        >
                          <div
                            className="tooltip top"
                            style={{ top: "-26px", left: "88.7708px" }}
                          >
                            <div className="tooltip-arrow" />
                            <div className="tooltip-inner" id="tooltip-inner2">205 : 450</div>
                          </div>
                          <input
                            type="text"
                            className="span2"
                            defaultValue
                            data-slider-min={0}
                            data-slider-max={600}
                            data-slider-step={5}
                            data-slider-value="[50,450]"
                            id="property-geo"
                            style={{}}
                          />
                        </div>
                        <br />
                        <b className="pull-left color">40m</b>
                        <b className="pull-right color">12000m</b>
                      </div>

                      {/* End of  */}
                      <div className="col-sm-3">
                        <label htmlFor="price-range">Deposite :</label>
                        <div
                          className="sliderrange slider slider-horizontal"
                          style={{ width: 235 }}
                        >
                          <div
                            className="tooltip top"
                            style={{ top: "-26px", left: "97.5833px" }}
                          >
                            <div className="tooltip-arrow" />
                            <div className="tooltip-inner" id="tooltip-inner3">250 : 450</div>
                          </div>
                          <input
                            type="text"
                            className="span2"
                            defaultValue
                            data-slider-min={0}
                            data-slider-max={600}
                            data-slider-step={5}
                            data-slider-value="[250,450]"
                            id="min-baths"
                            style={{}}
                          />
                        </div>
                        <br />
                        <b className="pull-left color">1</b>
                        <b className="pull-right color">120</b>
                      </div>

                      {/* End of  */}
                      <div className="col-sm-3">
                        <label htmlFor="property-geo"> bedroom :</label>
                        <div
                          className="sliderrange slider slider-horizontal"
                          style={{ width: 235 }}
                        >
                          <div
                            className="tooltip top"
                            style={{ top: "-26px", left: "78.9792px" }}
                          >
                            <div className="tooltip-arrow" />
                            <div className="tooltip-inner" id="tooltip-inner4">250 : 450</div>
                          </div>
                          <input
                            type="text"
                            className="span2"
                            defaultValue
                            data-slider-min={0}
                            data-slider-max={600}
                            data-slider-step={5}
                            data-slider-value="[250,450]"
                            id="min-bed"
                            style={{}}
                          />
                        </div>
                        <br />
                        <b className="pull-left color">1</b>
                        <b className="pull-right color">120</b>
                      </div>

                      {/* End of  */}
                    </div>

                    <div className="search-row">
                      <div className="col-sm-3">
                        <div className="checkbox">
                          <label>
                            <input type="checkbox" id="Filterfullfurniture" /> full furniture
                          </label>
                        </div>
                      </div>
                      {/* End of  */}
                      <div className="col-sm-3">
                        <div className="checkbox">
                          <label>
                            <input type="checkbox" id="Filtersemifurniture" /> semi furniture
                          </label>
                        </div>
                      </div>
                      {/* End of  */}
                      <div className="col-sm-3">
                        <div className="checkbox">
                          <label>
                            <input type="checkbox" id="FilterNonefurniture" /> None furniture
                          </label>
                        </div>
                      </div>
                      {/* End of  */}
                      <div className="col-sm-3">
                        <div className="checkbox">
                          <label>
                            <input type="checkbox" id="FilterSwimmingPool" /> Swimming Pool
                          </label>
                        </div>
                      </div>
                      {/* End of  */}
                      <div className="col-sm-3">
                        <div className="checkbox">
                          <label>
                            <input type="checkbox" id="FilterGym" /> Gym
                          </label>
                        </div>
                      </div>
                      {/* End of  */}
                      <div className="col-sm-3">
                        <div className="checkbox">
                          <label>
                            <input type="checkbox" id="FilterGarden" /> Garden
                          </label>
                        </div>
                      </div>
                      {/* End of  */}
                      <div className="col-sm-3">
                        <div className="checkbox">
                          <label>
                            <input type="checkbox" id="Filterswim" /> swim
                          </label>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="center">
                    <input
                      type="button"
                      defaultValue=""
                      className="btn btn-default btn-lg-sheach"
                      onClick={this.AllFilaterData}
                    />
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </>
    );
  }
}
